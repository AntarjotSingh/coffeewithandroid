# RecyclerView
Android Application - RecyclerView with custom view using sample data

![Alt text](https://github.com/AntarjotSingh/RecyclerView/blob/master/RecyclerView.gif?raw=true "Optional Title")
